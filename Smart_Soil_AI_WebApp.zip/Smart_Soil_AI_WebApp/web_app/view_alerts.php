<?php
session_start();
include("config.php");

$alerts = $conn->query("SELECT * FROM system_alerts ORDER BY timestamp DESC");
?>
<!DOCTYPE html>
<html>
<head><title>System Alerts</title></head>
<body>
<h3>📢 Recent System Alerts</h3>
<ul>
<?php while ($a = $alerts->fetch_assoc()): ?>
  <li><?= $a['timestamp'] ?> - <?= $a['message'] ?></li>
<?php endwhile; ?>
</ul>
</body>
</html>
