<?php
session_start();
include("config.php");
include("auto_recommendation.php");

$result = $conn->query("SELECT * FROM soil_data ORDER BY timestamp DESC LIMIT 1");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    $crop = predict_crop(
        $row['temperature'], $row['humidity'], $row['moisture_level'],
        $row['pH_level'], $row['nitrogen'], $row['phosphorous'], $row['potassium']
    );

    // Save AI recommendation to DB
    $stmt = $conn->prepare("UPDATE soil_data SET recommended_crop = ? WHERE soil_id = ?");
    $stmt->bind_param("si", $crop, $row['soil_id']);
    $stmt->execute();

    // Auto Alert (Simple Example)
    $alerts = [];
    if ($row['moisture_level'] < 30) {
        $alerts[] = "⚠️ Low Moisture (" . $row['moisture_level'] . "%)";
    }
    if ($row['pH_level'] < 5.5 || $row['pH_level'] > 8.5) {
        $alerts[] = "⚠️ Abnormal pH (" . $row['pH_level'] . ")";
    }
    if ($row['humidity'] < 30) {
        $alerts[] = "⚠️ Low Humidity (" . $row['humidity'] . "%)";
    }

    foreach ($alerts as $msg) {
        $stmt = $conn->prepare("INSERT INTO system_alerts (farmer_id, sensor_id, message, timestamp) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iis", $row['farmer_id'], $row['sensor_id'], $msg);
        $stmt->execute();
    }

    echo "✅ AI Crop Recommendation: " . $crop . "<br>";
    echo "Alerts: " . implode(", ", $alerts);
} else {
    echo "❌ No data available!";
}
?>
