import mysql.connector
import random
import time
import joblib
from datetime import datetime
import os




MODEL_PATH = "model/crop_predictor.pkl"
if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError("⚠️ Model not found. Ensure crop_predictor.pkl is in the 'model' folder.")

model = joblib.load('model/crop_predictor.pkl')


# ✅ Connect to database
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",  # weka password kama unayo
    database="smart_soil_system"
)
cursor = db.cursor()

# 🌱 Generate fake soil data
def generate_fake_data():
    return {
        "sensor_id": 1,
        "moisture": round(random.uniform(30, 90), 2),
        "ph": round(random.uniform(5.0, 7.5), 2),
        "temperature": round(random.uniform(20, 35), 2),
        "humidity": round(random.uniform(30, 90), 2),  # Added humidity
        "nitrogen": round(random.uniform(40, 150), 2),
        "phosphorous": round(random.uniform(10, 60), 2),
        "potassium": round(random.uniform(80, 200), 2)
    }


# 🧠 Predict crop using AI
def predict_crop(data):
    features = [[
        data["temperature"],
        data["humidity"],
        data["moisture"],
        data["ph"],
        data["nitrogen"],
        data["phosphorous"],
        data["potassium"]
    ]]

    le = joblib.load("model/label_encoder.pkl")
    prediction = model.predict(features)
    crop = le.inverse_transform(prediction)[0]  # Convert back to crop name
    return crop


    prediction = model.predict(features)[0]
    return prediction

# 💾 Insert data into DB
def insert_to_db(data, crop):
    sql = """
    INSERT INTO soil_data (
        sensor_id, moisture_level, pH_level, temperature,humidity,
        nitrogen, phosphorous, potassium, recommended_crop
    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    values = (
        data["sensor_id"],
        data["moisture"],
        data["ph"],
        data["temperature"],
        data["humidity"],
        data["nitrogen"],
        data["phosphorous"],
        data["potassium"],
        crop
    )
    cursor.execute(sql, values)
    db.commit()

# 🔁 Loop for continuous monitoring
try:
    while True:
        soil_data = generate_fake_data()
        crop = str(predict_crop(soil_data))
        insert_to_db(soil_data, crop)
        print(f"[{datetime.now()}] ✅ Data inserted | Crop: {crop}")
        time.sleep(10)  # delay between each insertion (10 seconds)
except KeyboardInterrupt:
    print("\n🔁 Monitoring stopped by user.")
    cursor.close()
    db.close()
