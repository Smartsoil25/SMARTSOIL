# 1. train_model.py - Train Random Forest Model
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import joblib

# Load Dataset
df = pd.read_csv('dataset.CSV')

X = df[['temperature', 'humidity', 'moisture', 'pH', 'N', 'P', 'K']]
y = df['crop_label']

le = LabelEncoder()
y_encoded = le.fit_transform(y)

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y_encoded)

joblib.dump(model, 'model/crop_predictor.pkl')
joblib.dump(le, 'model/label_encoder.pkl')
print("Model trained successfully!")