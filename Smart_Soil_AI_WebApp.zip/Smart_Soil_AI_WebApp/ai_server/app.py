# 2. app.py - WebSocket AI Server
import asyncio
import websockets
import json
import joblib
import numpy as np

model = joblib.load('model/crop_predictor.pkl')
le = joblib.load('model/label_encoder.pkl')

async def handle_client(websocket):
    async for message in websocket:
        data = json.loads(message)
        features = np.array([[
            data['temperature'],
            data['humidity'],
            data['moisture'],
            data['pH'],
            data['N'],
            data['P'],
            data['K']
        ]])
        prediction = model.predict(features)
        crop = le.inverse_transform(prediction)[0]
        response = {"crop": crop}
        await websocket.send(json.dumps(response))

async def main():
    async with websockets.serve(handle_client, "localhost", 6789):
        print("WebSocket AI Server running on ws://localhost:6789")
        await asyncio.Future()  # Run forever

asyncio.run(main())