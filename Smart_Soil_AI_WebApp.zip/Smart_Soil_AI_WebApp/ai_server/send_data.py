# 3. send_data.py - WebSocket Client to Test AI Server
import asyncio
import websockets
import json

async def send_test_data():
    uri = "ws://localhost:6789"
    async with websockets.connect(uri) as websocket:
        test_data = {
            "temperature": 25,
            "humidity": 55,
            "moisture": 35,
            "pH": 6.5,
            "N": 80,
            "P": 40,
            "K": 30
        }

        await websocket.send(json.dumps(test_data))
        response = await websocket.recv()
        print("AI Response:", response)

asyncio.run(send_test_data())